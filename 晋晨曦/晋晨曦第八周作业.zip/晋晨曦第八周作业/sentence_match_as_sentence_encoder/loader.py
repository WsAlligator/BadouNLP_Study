# -*- coding: utf-8 -*-

import json
import re
import os
import torch
import random
import jieba
import numpy as np
from torch.utils.data import Dataset, DataLoader
from collections import defaultdict
"""
数据加载
"""


class DataGenerator:
    def __init__(self, data_path, config):
        self.config = config
        self.path = data_path
        self.vocab = load_vocab(config["vocab_path"])
        self.config["vocab_size"] = len(self.vocab)
        self.schema = load_schema(config["schema_path"])
        self.train_data_size = config["epoch_data_size"] #由于采取随机采样，所以需要设定一个采样数量，否则可以一直采
        self.data_type = None  #用来标识加载的是训练集还是测试集 "train" or "test"
        self.load()

    def load(self):
        self.data = []
        self.knwb = defaultdict(list)
        with open(self.path, encoding="utf8") as f:
            sum=0
            for line in f:
                line = json.loads(line)
                #加载训练集
                if isinstance(line, dict):
                    self.data_type = "train"
                    questions = line["questions"]
                    label = line["target"]
                    for question in questions:
                        input_id = self.encode_sentence(question)
                        input_id = torch.LongTensor(input_id)
                        self.knwb[self.schema[label]].append(input_id)
                    # print(label,len(self.knwb[self.schema[label]]))
                    # sum+=len(self.knwb[self.schema[label]])
                    #训练集共1878个样本
                    # print(sum)
                        #训练集数据：knwb（dict）->{标题索引（数字）：【问题编码，问题编码...】}
                #加载测试集
                else:
                    self.data_type = "test"
                    assert isinstance(line, list)
                    question, label = line
                    input_id = self.encode_sentence(question)
                    input_id = torch.LongTensor(input_id)
                    label_index = torch.LongTensor([self.schema[label]])
                    self.data.append([input_id, label_index])
                    #data(list)->[[问题编码(list), 主题索引]*n]
        return

    def encode_sentence(self, text):
        input_id = []
        # "vocab_path":"../chars.txt"
        if self.config["vocab_path"] == "words.txt":
            for word in jieba.cut(text):
                input_id.append(self.vocab.get(word, self.vocab["[UNK]"]))
        else:
            for char in text:
                input_id.append(self.vocab.get(char, self.vocab["[UNK]"]))
        input_id = self.padding(input_id)
        return input_id

    #补齐或截断输入的序列，使其可以在一个batch内运算
    def padding(self, input_id):
        input_id = input_id[:self.config["max_length"]]
        input_id += [0] * (self.config["max_length"] - len(input_id))
        return input_id

    def __len__(self):
        if self.data_type == "train":
            return self.config["epoch_data_size"]
        else:
            assert self.data_type == "test", self.data_type
            return len(self.data)

    def __getitem__(self, index):
        if self.data_type == "train":
            return self.random_train_sample() #随机生成一个训练样本
        else:
            #data(list)->[[问题编码(list), 主题索引]*n]
            return self.data[index]

    #依照一定概率生成负样本或正样本
    #负样本从随机两个不同的标准问题中各随机选取一个
    #正样本从随机一个标准问题中随机选取两个
    def random_train_sample(self):
        #训练集数据：knwb（dict）->{标题索引（数字）：【问题编码】}
        standard_question_index = list(self.knwb.keys())
        #0-28,一共29个标准问题


        #三元组取样时先随机选择一个类文本列表
        anchor_index=random.choice(standard_question_index)
        tensor_positive_questions=self.knwb[anchor_index]
        positive_questions=[i.tolist() for i in tensor_positive_questions]
        if len(positive_questions)<2:
            return self.random_train_sample()

        # 在三元组损失（Triplet Loss）的语境中，anchor 的中文含义是 “锚点” 或 “原点”。

        anchor_question=random.choice(positive_questions)
        anchor_question_index=positive_questions.index(anchor_question)


        positive_questions=[i for i in positive_questions if positive_questions.index(i)!=anchor_question_index ]
        positive_question=random.choice(positive_questions)

        negative_QUES=[i for i in standard_question_index if i!=anchor_index]
        negative_QUES_index=random.choice(negative_QUES)
        negative_question=random.choice(self.knwb[negative_QUES_index])
        return [torch.LongTensor(anchor_question), torch.LongTensor(positive_question), negative_question]


#加载字表或词表
def load_vocab(vocab_path):
    token_dict = {}
    with open(vocab_path, encoding="utf8") as f:
        for index, line in enumerate(f):
            token = line.strip()
            token_dict[token] = index + 1  #0留给padding位置，所以从1开始
    return token_dict

#加载schema
def load_schema(schema_path):
    with open(schema_path, encoding="utf8") as f:
        return json.loads(f.read())

#用torch自带的DataLoader类封装数据
def load_data(data_path, config, shuffle=True):
    dg = DataGenerator(data_path, config)
    #"batch_size": 32,
    dl = DataLoader(dg, batch_size=config["batch_size"], shuffle=shuffle)
    return dl

from config import Config


if __name__ == "__main__":

    dg = DataGenerator(r"..\data\valid.json", Config)
    print(dg[0])
    dl=DataLoader(dg, batch_size=Config["batch_size"], shuffle=True)
    for i,batch_data in enumerate(dl):
        input_ids,indexs= batch_data
        print(input_ids.shape, indexs.shape)

